package org.example;
import javax.swing.*;
import java.awt.*;
public class JMyPanel extends JPanel {
    private Image image = null;
    public Image getImage() { return image; }
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (image == null) { image = createImage(getWidth(), getHeight()); }
        else { g.drawImage(image, 0, 0, this); }
    }
    public void clear() {
        if (image != null) {
            Graphics g = image.getGraphics();
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}
