package org.example;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
public class Maze {
    private List<Room> rooms = new ArrayList<>();
    public void addRoom(Room room) { rooms.add(room); }
    public void draw(Image image) {
        for (Room r : rooms) r.draw(image);
    }
    public List<Room> getRooms() { return rooms; }
    public void removeRoom(Room room) { rooms.remove(room); }
}
