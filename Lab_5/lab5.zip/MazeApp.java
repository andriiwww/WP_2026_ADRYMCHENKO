package org.example;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MazeApp extends JFrame {
    private JMyPanel panel;
    private Maze currentMaze;
    private MazeFactory currentFactory;
    private int nextRoomNr = 9; // Po wygenerowaniu 8 pokoi, kolejne będą numerowane od 9

    public MazeApp() {
        setTitle("Lab 5 - Wariant 1 (Fabryka + Magia)");
        setSize(800, 600);
        panel = new JMyPanel();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelButtons = new JPanel();
        panelButtons.setLayout(new GridLayout(1, 2));

        JButton btnStandard = new JButton("Rysuj Standardowy Labirynt");
        btnStandard.addActionListener(e -> {
            currentFactory = MazeFactory.getInstance();
            MazeGame game = new MazeGame();
            currentMaze = game.createMaze(currentFactory, 100, 100);
            nextRoomNr = 9;
            redrawMaze();
        });

        JButton btnMagic = new JButton("Rysuj Magiczny Labirynt");
        btnMagic.addActionListener(e -> {
            currentFactory = MagicMazeFactory.getInstance();
            MazeGame game = new MazeGame();
            currentMaze = game.createMaze(currentFactory, 300, 100);
            nextRoomNr = 9;
            redrawMaze();
        });
        
        // Obsługa kliknięć myszy: Lewy przycisk dodaje lub usuwa pokój
        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (currentMaze == null || currentFactory == null) return;
                
                int mouseX = e.getX();
                int mouseY = e.getY();
                int L = MapSite.L;
                
                Room clickedRoom = null;
                // Sprawdzamy, czy kliknięto w istniejący pokój
                for (Room r : currentMaze.getRooms()) {
                    if (mouseX >= r.getX() && mouseX <= r.getX() + L &&
                        mouseY >= r.getY() && mouseY <= r.getY() + L) {
                        clickedRoom = r;
                        break;
                    }
                }
                
                if (clickedRoom != null) {
                    // Jeśli kliknięto w pokój - usuwamy go z listy
                    currentMaze.removeRoom(clickedRoom);
                } else {
                    // Jeśli kliknięto w puste miejsce - tworzymy nowy pokój.
                    int gridX = (mouseX / L) * L;
                    int gridY = (mouseY / L) * L;
                    
                    Room newRoom = currentFactory.makeRoom(gridX, gridY, nextRoomNr++);
                    
                    // Otaczamy nowy pokój 4 ścianami na start
                    Color c = Color.BLACK;
                    newRoom.setSite(Directions.NORTH, currentFactory.makeWall(gridX, gridY, Directions.NORTH, c));
                    newRoom.setSite(Directions.EAST, currentFactory.makeWall(gridX, gridY, Directions.EAST, c));
                    newRoom.setSite(Directions.SOUTH, currentFactory.makeWall(gridX, gridY, Directions.SOUTH, c));
                    newRoom.setSite(Directions.WEST, currentFactory.makeWall(gridX, gridY, Directions.WEST, c));

                    // Losowo dodajemy minę (np. 50% szans)
                    if (Math.random() > 0.5) {
                        newRoom.setMine(currentFactory.makeMine(gridX, gridY));
                    }
                    
                    currentMaze.addRoom(newRoom);

                    // Szukamy sąsiadów, żeby automatycznie wstawić drzwi
                    for (Room r : currentMaze.getRooms()) {
                        if (r == newRoom) continue;
                        
                        // Sąsiad z lewej
                        if (r.getX() == gridX - L && r.getY() == gridY) {
                            currentFactory.makeDoor(r, newRoom, Color.BLUE);
                        }
                        // Sąsiad z prawej
                        else if (r.getX() == gridX + L && r.getY() == gridY) {
                            currentFactory.makeDoor(newRoom, r, Color.BLUE);
                        }
                        // Sąsiad z góry
                        else if (r.getX() == gridX && r.getY() == gridY - L) {
                            currentFactory.makeDoor(r, newRoom, Color.ORANGE);
                        }
                        // Sąsiad z dołu
                        else if (r.getX() == gridX && r.getY() == gridY + L) {
                            currentFactory.makeDoor(newRoom, r, Color.ORANGE);
                        }
                    }
                }
                redrawMaze(); // Odświeżamy widok po wprowadzonych zmianach
            }
        });

        panelButtons.add(btnStandard);
        panelButtons.add(btnMagic);
        add(panelButtons, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
    }
    
    // Metoda do czyszczenia panelu i ponownego narysowania aktualnego stanu
    private void redrawMaze() {
        panel.clear();
        if (currentMaze != null) {
            currentMaze.draw(panel.getImage());
        }
        panel.repaint();
    }

    public static void main(String[] args) { EventQueue.invokeLater(() -> new MazeApp().setVisible(true)); }
}
