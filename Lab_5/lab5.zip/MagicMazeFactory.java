package org.example;
import java.awt.Color;
public class MagicMazeFactory extends MazeFactory {
    private static MagicMazeFactory instance;
    protected MagicMazeFactory() {}
    public static MagicMazeFactory getInstance() {
        if (instance == null) { instance = new MagicMazeFactory(); }
        return instance;
    }
    @Override
    public Wall makeWall(int x, int y, Directions direction, Color color) { return new Wall(x, y, direction, new Color(138, 43, 226)); }
    @Override
    public Door makeDoor(Room r1, Room r2, Color color) { return new Door(r1, r2, Color.ORANGE); }
    @Override
    public Mine makeMine(int x, int y) { return new Mine(x, y, Color.GREEN); }
}
