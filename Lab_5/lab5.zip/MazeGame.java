package org.example;
import java.awt.Color;

public class MazeGame {
    public Maze createMaze(MazeFactory factory, int x, int y) {
        Maze maze = new Maze();
        Color color = Color.BLACK;
        int L = MapSite.L;
        int nr = 1;

        Room[][] grid = new Room[4][2];
        
        // Tworzymy 8 pokoi (siatka 4 kolumny na 2 wiersze)
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 2; j++) {
                int rx = x + i * L;
                int ry = y + j * L;
                Room r = factory.makeRoom(rx, ry, nr++);
                
                r.setSite(Directions.NORTH, factory.makeWall(rx, ry, Directions.NORTH, color));
                r.setSite(Directions.EAST, factory.makeWall(rx, ry, Directions.EAST, color));
                r.setSite(Directions.SOUTH, factory.makeWall(rx, ry, Directions.SOUTH, color));
                r.setSite(Directions.WEST, factory.makeWall(rx, ry, Directions.WEST, color));
                
                // Dodajemy miny w niektórych pokojach dla urozmaicenia
                if ((i + j) % 2 == 1) {
                    r.setMine(factory.makeMine(r.getX(), r.getY()));
                }
                
                grid[i][j] = r;
                maze.addRoom(r);
            }
        }

        // Łączymy niektóre pokoje drzwiami w poziomie
        factory.makeDoor(grid[0][0], grid[1][0], Color.BLUE);
        factory.makeDoor(grid[1][0], grid[2][0], Color.RED);
        factory.makeDoor(grid[2][0], grid[3][0], Color.BLUE);
        
        factory.makeDoor(grid[0][1], grid[1][1], Color.RED);
        factory.makeDoor(grid[2][1], grid[3][1], Color.RED);

        // Łączymy niektóre pokoje drzwiami w pionie
        factory.makeDoor(grid[1][0], grid[1][1], Color.ORANGE);
        factory.makeDoor(grid[3][0], grid[3][1], Color.ORANGE);

        return maze;
    }
}
